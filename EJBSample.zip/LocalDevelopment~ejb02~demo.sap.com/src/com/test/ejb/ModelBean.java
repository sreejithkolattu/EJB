package com.test.ejb;

import javax.naming.InitialContext;

import com.test.ejb01.SampleClassRemote;


public class ModelBean {

	public String testMethod(){
			try {
			InitialContext ctx = new InitialContext();
			String lookupString = "ejb:/interfaceName=com.test.ejb01.SampleClass";
			Object obj = ctx.lookup(lookupString);
			
			SampleClassRemote ejbHome = (SampleClassRemote) javax.rmi.PortableRemoteObject.narrow(obj, SampleClassRemote.class);		
			String test = ejbHome.testMyMethod(":Ram");			
			return test;
		} catch (Exception e) {
			e.toString();
			return e.toString();
		}
	}
}
