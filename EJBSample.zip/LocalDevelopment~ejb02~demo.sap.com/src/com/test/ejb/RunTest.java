package com.test.ejb;

public class RunTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ModelBean modelbean = new ModelBean(); 
		String testResult = modelbean.testMethod();
		System.out.print(testResult);
	}

}
