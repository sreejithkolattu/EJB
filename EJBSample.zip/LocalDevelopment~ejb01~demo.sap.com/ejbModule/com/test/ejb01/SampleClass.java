package com.test.ejb01;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class SampleClass
 */
@Stateless
public class SampleClass implements SampleClassRemote {

    /**
     * Default constructor. 
     */
    public SampleClass() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String testMyMethod(String text) {
		// TODO Auto-generated method stub
		return "Success:"+text;
	}

}
