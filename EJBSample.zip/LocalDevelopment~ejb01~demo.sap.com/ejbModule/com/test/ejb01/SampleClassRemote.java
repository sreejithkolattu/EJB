package com.test.ejb01;
import javax.ejb.Remote;

@Remote
public interface SampleClassRemote {
 String testMyMethod(String text);
}
